package com.uas.java1.model;

public enum StatusPengirimanTugas {
    BELUM_TERKIRIM,
    TERKIRIM
}
