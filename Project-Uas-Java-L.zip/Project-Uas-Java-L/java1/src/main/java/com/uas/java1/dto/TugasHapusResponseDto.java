package com.uas.java1.dto;

import java.time.LocalDate;

import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TugasHapusResponseDto {
    private Long id;
    
    private String title;

    private String description;

    private LocalDate deadline;

    private String status;
}
