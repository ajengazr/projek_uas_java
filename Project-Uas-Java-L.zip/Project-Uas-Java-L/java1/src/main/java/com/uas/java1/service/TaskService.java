package com.uas.java1.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.stereotype.Service;

import com.uas.java1.dto.AdminTaskRequestDto;
import com.uas.java1.dto.TaskDto;
import com.uas.java1.exception.ExceptionStatus;
import com.uas.java1.exception.TidakDitemukan;
import com.uas.java1.model.Task;
import com.uas.java1.model.User;
import com.uas.java1.repository.TaskRepository;
import com.uas.java1.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TaskService {
    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public Task getTaskById(Long id) {
        return taskRepository.findById(id).orElseThrow(() -> new RuntimeException("Task tidak ditemukan"));
    }

    public Task createTask(TaskDto taskDto) {
        // assignedTo tidak boleh null
        if (taskDto.getAssignedTo() == null) {
            throw new ExceptionStatus("Field 'assigned_to' wajib diisi");
        }

        // assignedTo tidak boleh 0, 1, atau negatif
        if (taskDto.getAssignedTo() <= 1) {
            throw new ExceptionStatus("Field 'assigned_to' tidak boleh bernilai 1, 0, atau angka negatif");
        }

        // title dan description tidak boleh sama
        if (taskDto.getTitle().trim().equalsIgnoreCase(taskDto.getDescription().trim())) {
            throw new ExceptionStatus("Title dan Description tidak boleh sama persis");
        }

        // pastikan user dengan ID tersebut ada
        User assignedUser = userRepository.findById(taskDto.getAssignedTo())
                .orElseThrow(
                        () -> new TidakDitemukan("User dengan ID " + taskDto.getAssignedTo() + " tidak ditemukan"));

        Task newTask = Task.builder()
                .title(taskDto.getTitle())
                .description(taskDto.getDescription())
                .assignedTo(assignedUser)
                .deadline(taskDto.getDeadline())
                .status("In-Progress")
                .build();

        return taskRepository.save(newTask);
    }

    public Task updateTask(Long id, AdminTaskRequestDto updatedTask) {
        Task existingTask = getTaskById(id);

        // validasi hanya jika status masih In-Progress
        if (!"In-Progress".equalsIgnoreCase(existingTask.getStatus())) {
            throw new ExceptionStatus(
                    "Task hanya bisa diubah jika statusnya masih 'In-Progress'");
        }

        // update description
        existingTask.setDescription(updatedTask.getDeskripsi());
        existingTask.setTitle(updatedTask.getTittle());

        // validasi dan update deadline
        if (updatedTask.getDeadline() != null && !updatedTask.getDeadline().isEqual(existingTask.getDeadline())) {
            LocalDate today = LocalDate.now(); // hanya tanggal
            LocalDate deadline = existingTask.getDeadline(); // pastikan juga LocalDate
            long selisihHari = ChronoUnit.DAYS.between(today, deadline);
            System.out.println(selisihHari);
            LocalDate deadlineBaru = updatedTask.getDeadline();
            LocalDate deadlineLama = existingTask.getDeadline();
            LocalDate hariSekarang = LocalDate.now();

            if (selisihHari > 3) {
                if (deadlineBaru.isAfter(deadlineLama)) {
                    if (ChronoUnit.DAYS.between(deadlineLama, deadlineBaru) > 2) {
                        throw new ExceptionStatus("Deadline hanya boleh ditunda maksimal 2 hari dari deadline lama.");
                    }
                } else if (deadlineBaru.isBefore(deadlineLama)) {
                    long hariMundur = ChronoUnit.DAYS.between(hariSekarang, deadlineBaru);
                    if (hariMundur < 3) {
                        throw new ExceptionStatus("Deadline hanya boleh dipercepat maksimal 2 hari dari hari ini.");
                    }
                }
            } else {
                throw new ExceptionStatus("deadline tidak bisa diedit, karena sudah mendekati 3 hari waktu deadline.");
            }
            existingTask.setDeadline(deadlineBaru);
        }

        return taskRepository.save(existingTask);
    }

    public void deleteTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new TidakDitemukan("Task tidak ditemukan dengan ID : " + id));
        if (task.getStatus().equals("COMPLETED")) {
            throw new ExceptionStatus("Task yang sudah COMPLETED tidak bisa di hapus");
        }
        System.out.println("ini data TASK : " + task);
        taskRepository.delete(task);
    }

    public List<Task> getTasksByAssignedUser(User user) {
        return taskRepository.findByAssignedTo(user);
    }
}
