package com.uas.java1.exception;

public class ExceptionStatus extends RuntimeException{
    public ExceptionStatus(String pesan) {
        super(pesan);
    }
}
