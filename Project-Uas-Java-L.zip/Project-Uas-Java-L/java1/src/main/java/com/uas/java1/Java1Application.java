package com.uas.java1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java1Application {

	public static void main(String[] args) {
		SpringApplication.run(Java1Application.class, args);
	}

}
